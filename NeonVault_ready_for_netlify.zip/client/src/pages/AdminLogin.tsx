import { useState } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Shield, ArrowLeft, Unlock } from "lucide-react";

export default function AdminLogin() {
  const [code, setCode] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async (code: string) => {
      const response = await apiRequest("POST", "/api/admin/login", { code });
      return response.json();
    },
    onSuccess: (data) => {
      localStorage.setItem("adminSessionId", data.sessionId);
      toast({
        title: "Authentication successful",
        description: "Welcome to the admin dashboard.",
      });
      setLocation("/admin/dashboard");
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Authentication failed",
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.trim()) {
      loginMutation.mutate(code.trim());
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Card className="glass-card neon-border" data-testid="card-admin-login">
          <CardHeader className="text-center space-y-4">
            <motion.div
              className="mx-auto"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Shield className="text-primary" size={48} />
            </motion.div>
            <div>
              <CardTitle className="text-3xl font-bold font-mono text-primary">
                ADMIN ACCESS
              </CardTitle>
              <p className="text-muted-foreground mt-2">
                Enter authentication code to continue
              </p>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="admin-code" className="text-sm font-medium">
                  Authentication Code
                </Label>
                <Input
                  id="admin-code"
                  type="password"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full bg-input border-border font-mono focus:border-primary focus:ring-primary/20"
                  placeholder="Enter admin code..."
                  required
                  data-testid="input-admin-code"
                />
              </div>

              <Button
                type="submit"
                className="w-full neon-border bg-primary/10 hover:bg-primary/20 text-primary font-semibold neon-glow"
                disabled={loginMutation.isPending || !code.trim()}
                data-testid="button-admin-login"
              >
                {loginMutation.isPending ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                    Authenticating...
                  </div>
                ) : (
                  <>
                    <Unlock className="mr-2" size={16} />
                    Access Admin Dashboard
                  </>
                )}
              </Button>
            </form>

            <div className="text-center">
              <Button
                variant="ghost"
                onClick={() => setLocation("/")}
                className="text-muted-foreground hover:text-primary"
                data-testid="button-back-home"
              >
                <ArrowLeft className="mr-2" size={16} />
                Back to Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
