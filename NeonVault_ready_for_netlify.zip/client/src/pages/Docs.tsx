import { useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, ChevronDown, ChevronRight } from "lucide-react";

interface DocSection {
  id: string;
  title: string;
  content: React.ReactNode;
}

export default function Docs() {
  const [searchTerm, setSearchTerm] = useState("");
  const [openSections, setOpenSections] = useState<Set<string>>(new Set(["getting-started"]));

  const toggleSection = (sectionId: string) => {
    const newOpenSections = new Set(openSections);
    if (newOpenSections.has(sectionId)) {
      newOpenSections.delete(sectionId);
    } else {
      newOpenSections.add(sectionId);
    }
    setOpenSections(newOpenSections);
  };

  const docSections: DocSection[] = [
    {
      id: "getting-started",
      title: "Getting Started",
      content: (
        <div className="prose prose-invert max-w-none">
          <h3 className="text-primary">Welcome to NeonVault</h3>
          <p>NeonVault is a secure file management system designed for modern web applications. Follow these steps to get started:</p>
          <ol className="text-muted-foreground space-y-2">
            <li>Browse public files in the Downloads section</li>
            <li>Use search and filters to find specific files</li>
            <li>Download files with a single click</li>
            <li>Admins can access the admin panel for file management</li>
          </ol>
        </div>
      ),
    },
    {
      id: "api-reference",
      title: "API Reference",
      content: (
        <div className="prose prose-invert max-w-none">
          <h3 className="text-primary">Endpoints</h3>
          <div className="space-y-4">
            <div className="bg-secondary p-4 rounded font-mono text-sm">
              <span className="text-primary">GET</span> /api/files - Get all files
            </div>
            <div className="bg-secondary p-4 rounded font-mono text-sm">
              <span className="text-primary">POST</span> /api/files/upload - Upload new file (Admin only)
            </div>
            <div className="bg-secondary p-4 rounded font-mono text-sm">
              <span className="text-primary">DELETE</span> /api/files/:id - Delete file (Admin only)
            </div>
            <div className="bg-secondary p-4 rounded font-mono text-sm">
              <span className="text-primary">GET</span> /api/categories - Get all categories
            </div>
          </div>
        </div>
      ),
    },
    {
      id: "security",
      title: "Security",
      content: (
        <div className="prose prose-invert max-w-none">
          <h3 className="text-primary">Authentication</h3>
          <p>Admin access is protected by a secure authentication system:</p>
          <ul className="text-muted-foreground space-y-1">
            <li>Server-side code verification</li>
            <li>Session-based authentication</li>
            <li>Secure file upload validation</li>
            <li>Rate limiting on API endpoints</li>
          </ul>
        </div>
      ),
    },
    {
      id: "file-management",
      title: "File Management",
      content: (
        <div className="prose prose-invert max-w-none">
          <h3 className="text-primary">Upload Guidelines</h3>
          <p>When uploading files through the admin panel:</p>
          <ul className="text-muted-foreground space-y-1">
            <li>Maximum file size: 100MB</li>
            <li>Supported formats: All file types</li>
            <li>Drag and drop interface available</li>
            <li>Files are automatically categorized</li>
            <li>Download tracking is enabled by default</li>
          </ul>
        </div>
      ),
    },
  ];

  const filteredSections = docSections.filter(
    section =>
      section.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (section.content && section.content.toString().toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.div
        className="mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold mb-4 font-mono text-primary">Documentation</h1>
        <div className="relative">
          <Input
            type="text"
            placeholder="Search documentation..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-input border-border pl-10 focus:border-primary focus:ring-primary/20"
            data-testid="input-search-docs"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
        </div>
      </motion.div>

      <motion.div
        className="space-y-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        {filteredSections.map((section, index) => (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
          >
            <Card className="glass-card overflow-hidden" data-testid={`card-doc-${section.id}`}>
              <Button
                variant="ghost"
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-primary/5 transition-colors"
                onClick={() => toggleSection(section.id)}
                data-testid={`button-toggle-${section.id}`}
              >
                <h2 className="text-xl font-semibold">{section.title}</h2>
                {openSections.has(section.id) ? (
                  <ChevronDown className="transform transition-transform" />
                ) : (
                  <ChevronRight className="transform transition-transform" />
                )}
              </Button>
              {openSections.has(section.id) && (
                <motion.div
                  className="px-6 pb-6"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  data-testid={`content-${section.id}`}
                >
                  {section.content}
                </motion.div>
              )}
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {filteredSections.length === 0 && searchTerm && (
        <motion.div
          className="text-center py-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4 }}
        >
          <p className="text-muted-foreground" data-testid="text-no-results">
            No documentation found for "{searchTerm}"
          </p>
        </motion.div>
      )}
    </div>
  );
}
