import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronRight } from "lucide-react";

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  isCommon?: boolean;
}

export default function FAQ() {
  const [openItems, setOpenItems] = useState<Set<string>>(new Set());

  const toggleItem = (itemId: string) => {
    const newOpenItems = new Set(openItems);
    if (newOpenItems.has(itemId)) {
      newOpenItems.delete(itemId);
    } else {
      newOpenItems.add(itemId);
    }
    setOpenItems(newOpenItems);
  };

  const faqItems: FAQItem[] = [
    {
      id: "download-files",
      question: "How do I download files?",
      answer: "Navigate to the Downloads page, browse or search for the file you need, and click the download button. All files are publicly accessible without requiring login.",
      isCommon: true,
    },
    {
      id: "become-admin",
      question: "How do I become an admin?",
      answer: "Admin access is restricted and requires a special authentication code. Contact the system administrator to request admin privileges if you need to upload or manage files.",
      isCommon: true,
    },
    {
      id: "file-size-limits",
      question: "Are there file size limits?",
      answer: "File upload limits depend on server configuration. Generally, files up to 100MB are supported. For larger files, contact the administrator for special arrangements.",
      isCommon: true,
    },
    {
      id: "file-preview",
      question: "Can I preview files before downloading?",
      answer: "Yes! NeonVault supports previewing images and PDFs directly in the browser. Click the preview button next to supported file types.",
      isCommon: false,
    },
    {
      id: "download-tracking",
      question: "Is my download activity tracked?",
      answer: "Download counters are maintained for analytics purposes, but personal information is not stored. Only file access statistics are tracked, not user identities.",
      isCommon: false,
    },
    {
      id: "upload-requirements",
      question: "What are the requirements for uploading files?",
      answer: "Only admin users can upload files. There are no specific file type restrictions, but files must be under the size limit and pass security validation.",
      isCommon: false,
    },
    {
      id: "system-security",
      question: "How secure is the system?",
      answer: "NeonVault uses advanced security measures including server-side authentication, session management, file validation, and encrypted storage for admin operations.",
      isCommon: false,
    },
  ];

  const commonQuestions = faqItems.filter(item => item.isCommon);
  const otherQuestions = faqItems.filter(item => !item.isCommon);

  const FAQSection = ({ title, items }: { title: string; items: FAQItem[] }) => (
    <div className="mb-8">
      <h2 className="text-2xl font-semibold mb-4 text-accent">{title}</h2>
      <div className="space-y-4">
        {items.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
          >
            <Card className="glass-card overflow-hidden" data-testid={`card-faq-${item.id}`}>
              <Button
                variant="ghost"
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-primary/5 transition-colors"
                onClick={() => toggleItem(item.id)}
                data-testid={`button-toggle-${item.id}`}
              >
                <h3 className="font-semibold">{item.question}</h3>
                {openItems.has(item.id) ? (
                  <ChevronDown className="transform transition-transform" />
                ) : (
                  <ChevronRight className="transform transition-transform" />
                )}
              </Button>
              {openItems.has(item.id) && (
                <motion.div
                  className="px-6 pb-6"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  data-testid={`content-${item.id}`}
                >
                  <p className="text-muted-foreground">{item.answer}</p>
                </motion.div>
              )}
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <motion.h1
        className="text-4xl font-bold mb-8 font-mono text-primary"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        Frequently Asked Questions
      </motion.h1>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <FAQSection title="Most Common Questions" items={commonQuestions} />
        <FAQSection title="Other Questions" items={otherQuestions} />
      </motion.div>
    </div>
  );
}
