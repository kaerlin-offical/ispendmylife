import { type User, type InsertUser, type Category, type InsertCategory, type File, type InsertFile, type FileWithCategory, type InsertDownloadLog, type DownloadLog } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  deleteCategory(id: string): Promise<boolean>;
  
  // File methods
  getFiles(): Promise<FileWithCategory[]>;
  getFile(id: string): Promise<FileWithCategory | undefined>;
  getFilesByCategory(categoryId: string): Promise<FileWithCategory[]>;
  createFile(file: InsertFile): Promise<File>;
  deleteFile(id: string): Promise<boolean>;
  updateFileDownloadCount(id: string): Promise<boolean>;
  
  // Download log methods
  createDownloadLog(log: InsertDownloadLog): Promise<DownloadLog>;
  getDownloadStats(): Promise<{ totalDownloads: number; downloadsToday: number }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private categories: Map<string, Category>;
  private files: Map<string, File>;
  private downloadLogs: Map<string, DownloadLog>;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.files = new Map();
    this.downloadLogs = new Map();
    
    // Initialize with default categories
    this.initializeDefaultCategories();
    this.initializeDefaultFiles();
  }

  private initializeDefaultCategories() {
    const defaultCategories = [
      { name: "Documents", icon: "fas fa-file-alt" },
      { name: "Software", icon: "fas fa-cog" },
      { name: "Images", icon: "fas fa-image" },
      { name: "Media", icon: "fas fa-play-circle" },
    ];

    defaultCategories.forEach(cat => {
      const id = randomUUID();
      const category: Category = {
        id,
        name: cat.name,
        icon: cat.icon,
        createdAt: new Date(),
      };
      this.categories.set(id, category);
    });
  }

  private initializeDefaultFiles() {
    const categoriesArray = Array.from(this.categories.values());
    const docsCategory = categoriesArray.find(c => c.name === "Documents");
    const softwareCategory = categoriesArray.find(c => c.name === "Software");
    const imagesCategory = categoriesArray.find(c => c.name === "Images");

    const defaultFiles = [
      {
        name: "neonvault-manual.pdf",
        originalName: "NeonVault_Manual.pdf",
        size: 2400000,
        mimeType: "application/pdf",
        categoryId: docsCategory?.id,
        downloadCount: 156,
      },
      {
        name: "api-documentation.docx",
        originalName: "API_Documentation.docx",
        size: 1800000,
        mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        categoryId: docsCategory?.id,
        downloadCount: 89,
      },
      {
        name: "neonos-v2.1.iso",
        originalName: "NeonOS_v2.1.iso",
        size: 1200000000,
        mimeType: "application/octet-stream",
        categoryId: softwareCategory?.id,
        downloadCount: 2547,
      },
      {
        name: "cybertools-bundle.zip",
        originalName: "CyberTools_Bundle.zip",
        size: 486000000,
        mimeType: "application/zip",
        categoryId: softwareCategory?.id,
        downloadCount: 1834,
      },
      {
        name: "neonterminal-v3.2.zip",
        originalName: "NeonTerminal_v3.2.zip",
        size: 45600000,
        mimeType: "application/zip",
        categoryId: softwareCategory?.id,
        downloadCount: 743,
      },
      {
        name: "matrix-wallpapers.zip",
        originalName: "Matrix_Wallpapers.zip",
        size: 125000000,
        mimeType: "application/zip",
        categoryId: imagesCategory?.id,
        downloadCount: 1456,
      },
    ];

    defaultFiles.forEach(file => {
      const id = randomUUID();
      const fileEntity: File = {
        id,
        ...file,
        categoryId: file.categoryId || null,
        createdAt: new Date(),
      };
      this.files.set(id, fileEntity);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = {
      id,
      ...insertCategory,
      icon: insertCategory.icon || "fas fa-folder",
      createdAt: new Date(),
    };
    this.categories.set(id, category);
    return category;
  }

  async deleteCategory(id: string): Promise<boolean> {
    return this.categories.delete(id);
  }

  async getFiles(): Promise<FileWithCategory[]> {
    const files = Array.from(this.files.values());
    return files.map(file => ({
      ...file,
      category: file.categoryId ? this.categories.get(file.categoryId) || null : null,
    })).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getFile(id: string): Promise<FileWithCategory | undefined> {
    const file = this.files.get(id);
    if (!file) return undefined;
    
    return {
      ...file,
      category: file.categoryId ? this.categories.get(file.categoryId) || null : null,
    };
  }

  async getFilesByCategory(categoryId: string): Promise<FileWithCategory[]> {
    const files = Array.from(this.files.values()).filter(file => file.categoryId === categoryId);
    return files.map(file => ({
      ...file,
      category: this.categories.get(categoryId) || null,
    }));
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const id = randomUUID();
    const file: File = {
      id,
      ...insertFile,
      categoryId: insertFile.categoryId || null,
      downloadCount: 0,
      createdAt: new Date(),
    };
    this.files.set(id, file);
    return file;
  }

  async deleteFile(id: string): Promise<boolean> {
    return this.files.delete(id);
  }

  async updateFileDownloadCount(id: string): Promise<boolean> {
    const file = this.files.get(id);
    if (!file) return false;
    
    file.downloadCount += 1;
    this.files.set(id, file);
    return true;
  }

  async createDownloadLog(insertLog: InsertDownloadLog): Promise<DownloadLog> {
    const id = randomUUID();
    const log: DownloadLog = {
      id,
      ...insertLog,
      downloadedAt: new Date(),
    };
    this.downloadLogs.set(id, log);
    return log;
  }

  async getDownloadStats(): Promise<{ totalDownloads: number; downloadsToday: number }> {
    const totalDownloads = Array.from(this.files.values()).reduce((sum, file) => sum + file.downloadCount, 0);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const downloadsToday = Array.from(this.downloadLogs.values()).filter(
      log => log.downloadedAt >= today
    ).length;
    
    return { totalDownloads, downloadsToday };
  }
}

export const storage = new MemStorage();
